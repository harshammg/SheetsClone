import React, { useCallback } from 'react';
import { useSpreadsheetStore } from '../store/spreadsheetStore';
import { CellPosition } from '../types/spreadsheet';

const COLUMN_HEADERS = Array.from({ length: 26 }, (_, i) =>
  String.fromCharCode(65 + i)
);

export const Grid: React.FC = () => {
  const {
    cells,
    selectedCell,
    selectCell,
    updateCell,
    numRows,
    numCols
  } = useSpreadsheetStore();

  const getCellId = (row: number, col: number) => {
    return `${COLUMN_HEADERS[col]}${row + 1}`;
  };

  const handleCellClick = useCallback((position: CellPosition) => {
    const cellId = getCellId(position.row, position.col);
    selectCell(cellId);
  }, [selectCell]);

  const handleCellChange = useCallback((
    position: CellPosition,
    value: string
  ) => {
    const cellId = getCellId(position.row, position.col);
    updateCell(cellId, { value, formula: value });
  }, [updateCell]);

  return (
    <div className="flex-1 overflow-auto">
      <div className="inline-block min-w-full">
        <div className="sticky top-0 z-10 bg-gray-100">
          <div className="flex">
            <div className="w-10 h-6 bg-gray-200 border-r border-b"></div>
            {COLUMN_HEADERS.slice(0, numCols).map((header) => (
              <div
                key={header}
                className="w-24 h-6 flex items-center justify-center bg-gray-200 border-r border-b font-semibold text-gray-600"
              >
                {header}
              </div>
            ))}
          </div>
        </div>
        <div>
          {Array.from({ length: numRows }, (_, row) => (
            <div key={row} className="flex">
              <div className="sticky left-0 w-10 h-6 flex items-center justify-center bg-gray-200 border-r border-b font-semibold text-gray-600">
                {row + 1}
              </div>
              {Array.from({ length: numCols }, (_, col) => {
                const cellId = getCellId(row, col);
                const cell = cells[cellId];
                const isSelected = selectedCell === cellId;

                return (
                  <div
                    key={cellId}
                    className={`w-24 h-6 border-r border-b ${
                      isSelected ? 'bg-blue-50 outline outline-2 outline-blue-500 z-10' : 'bg-white'
                    }`}
                    onClick={() => handleCellClick({ row, col })}
                  >
                    {isSelected ? (
                      <input
                        type="text"
                        value={cell?.value || ''}
                        onChange={(e) => handleCellChange({ row, col }, e.target.value)}
                        className="w-full h-full px-1 bg-transparent border-none focus:outline-none"
                        autoFocus
                      />
                    ) : (
                      <div className="w-full h-full px-1 overflow-hidden whitespace-nowrap">
                        {cell?.value || ''}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};