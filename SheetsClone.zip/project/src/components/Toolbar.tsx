import React from 'react';
import {
  Bold,
  Italic,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Type,
  Palette
} from 'lucide-react';
import { useSpreadsheetStore } from '../store/spreadsheetStore';

export const Toolbar: React.FC = () => {
  const { selectedCell, cells, updateCell } = useSpreadsheetStore();
  
  const selectedCellData = selectedCell ? cells[selectedCell] : null;

  const toggleFormat = (formatKey: 'bold' | 'italic') => {
    if (!selectedCell || !selectedCellData) return;
    
    updateCell(selectedCell, {
      format: {
        ...selectedCellData.format,
        [formatKey]: !selectedCellData.format[formatKey]
      }
    });
  };

  return (
    <div className="flex items-center gap-2 p-2 border-b bg-white">
      <button
        className={`p-1 rounded hover:bg-gray-100 ${
          selectedCellData?.format.bold ? 'bg-gray-200' : ''
        }`}
        onClick={() => toggleFormat('bold')}
      >
        <Bold size={18} />
      </button>
      <button
        className={`p-1 rounded hover:bg-gray-100 ${
          selectedCellData?.format.italic ? 'bg-gray-200' : ''
        }`}
        onClick={() => toggleFormat('italic')}
      >
        <Italic size={18} />
      </button>
      <div className="w-px h-6 bg-gray-300 mx-2" />
      <button className="p-1 rounded hover:bg-gray-100">
        <AlignLeft size={18} />
      </button>
      <button className="p-1 rounded hover:bg-gray-100">
        <AlignCenter size={18} />
      </button>
      <button className="p-1 rounded hover:bg-gray-100">
        <AlignRight size={18} />
      </button>
      <div className="w-px h-6 bg-gray-300 mx-2" />
      <button className="p-1 rounded hover:bg-gray-100">
        <Type size={18} />
      </button>
      <button className="p-1 rounded hover:bg-gray-100">
        <Palette size={18} />
      </button>
    </div>
  );
};