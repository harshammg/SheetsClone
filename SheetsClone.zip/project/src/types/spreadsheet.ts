export interface CellData {
  id: string;
  value: string;
  formula: string;
  format: CellFormat;
}

export interface CellFormat {
  bold: boolean;
  italic: boolean;
  fontSize: number;
  color: string;
}

export interface SpreadsheetState {
  cells: { [key: string]: CellData };
  selectedCell: string | null;
  columnWidths: { [key: string]: number };
  rowHeights: { [key: string]: number };
  numRows: number;
  numCols: number;
}

export type CellPosition = {
  row: number;
  col: number;
};