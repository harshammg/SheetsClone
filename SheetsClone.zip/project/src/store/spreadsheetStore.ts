import { create } from 'zustand';
import { SpreadsheetState, CellData } from '../types/spreadsheet';
import { evaluateFormula } from '../utils/formulas';

const INITIAL_ROWS = 100;
const INITIAL_COLS = 26;

const createInitialState = (): SpreadsheetState => ({
  cells: {},
  selectedCell: null,
  columnWidths: {},
  rowHeights: {},
  numRows: INITIAL_ROWS,
  numCols: INITIAL_COLS,
});

export const useSpreadsheetStore = create<SpreadsheetState & {
  updateCell: (id: string, updates: Partial<CellData>) => void;
  selectCell: (id: string | null) => void;
  updateColumnWidth: (col: string, width: number) => void;
  updateRowHeight: (row: string, height: number) => void;
}>((set, get) => ({
  ...createInitialState(),

  updateCell: (id, updates) => {
    set((state) => {
      const cell = state.cells[id] || {
        id,
        value: '',
        formula: '',
        format: { bold: false, italic: false, fontSize: 14, color: '#000000' }
      };

      const updatedCell = { ...cell, ...updates };

      // If there's a formula, evaluate it
      if (updatedCell.formula.startsWith('=')) {
        updatedCell.value = evaluateFormula(updatedCell.formula, state.cells);
      }

      return {
        cells: {
          ...state.cells,
          [id]: updatedCell
        }
      };
    });
  },

  selectCell: (id) => set({ selectedCell: id }),

  updateColumnWidth: (col, width) =>
    set((state) => ({
      columnWidths: { ...state.columnWidths, [col]: width }
    })),

  updateRowHeight: (row, height) =>
    set((state) => ({
      rowHeights: { ...state.rowHeights, [row]: height }
    })),
}));