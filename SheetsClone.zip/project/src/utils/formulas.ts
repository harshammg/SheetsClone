import { CellData } from '../types/spreadsheet';

type FormulaFunction = (args: string[], cells: { [key: string]: CellData }) => string;

const formulaFunctions: { [key: string]: FormulaFunction } = {
  SUM: (args, cells) => {
    const values = args.map(ref => parseFloat(cells[ref]?.value || '0'));
    return values.reduce((a, b) => a + b, 0).toString();
  },

  AVERAGE: (args, cells) => {
    const values = args.map(ref => parseFloat(cells[ref]?.value || '0'));
    const sum = values.reduce((a, b) => a + b, 0);
    return (sum / values.length).toString();
  },

  MAX: (args, cells) => {
    const values = args.map(ref => parseFloat(cells[ref]?.value || '-Infinity'));
    return Math.max(...values).toString();
  },

  MIN: (args, cells) => {
    const values = args.map(ref => parseFloat(cells[ref]?.value || 'Infinity'));
    return Math.min(...values).toString();
  },

  COUNT: (args, cells) => {
    return args.filter(ref => {
      const value = cells[ref]?.value;
      return value && !isNaN(parseFloat(value));
    }).length.toString();
  },

  TRIM: (args, cells) => {
    const value = cells[args[0]]?.value || '';
    return value.trim();
  },

  UPPER: (args, cells) => {
    const value = cells[args[0]]?.value || '';
    return value.toUpperCase();
  },

  LOWER: (args, cells) => {
    const value = cells[args[0]]?.value || '';
    return value.toLowerCase();
  }
};

export const evaluateFormula = (formula: string, cells: { [key: string]: CellData }): string => {
  if (!formula.startsWith('=')) return formula;

  const functionMatch = formula.match(/^=(\w+)\((.*)\)$/);
  if (!functionMatch) return '#ERROR!';

  const [, functionName, argsString] = functionMatch;
  const args = argsString.split(',').map(arg => arg.trim());

  const fn = formulaFunctions[functionName];
  if (!fn) return '#NAME?';

  try {
    return fn(args, cells);
  } catch (error) {
    return '#ERROR!';
  }
};